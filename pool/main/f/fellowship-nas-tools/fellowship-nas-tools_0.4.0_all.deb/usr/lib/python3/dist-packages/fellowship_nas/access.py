"""Who may reach the NAS's sharing services: the local network, and the clients
an admin authorizes service by service (docs/fellowship-nas-firewall-plan.md).

Reaching a service is one of three separate things. Administration is
nas-admins' alone, and what an account may read or change is the share's
access list. Authorizing a client here lets its packets through to SMB, NFS or
SFTP and puts it in Samba's hosts allow or the NFS exports; it never grants an
account anything and never bypasses a share's permissions. The HTTPS desktop,
Files and WebDAV are open to everyone and aren't decided here.

NFS doesn't authenticate a user: it trusts the client machine and the IDs it
sends. So an NFS client is authorized as an account, and every request it makes
is squashed to that account's IDs, on exactly the shares the account may use.
"""
import ipaddress
import pwd
import re

from .common import ACCOUNT_NAME, FnasError, locked, read_json, write_json

ACCESS_FILE = "/etc/fellowshipos/nas-access.json"
ACCESS_LOCK = "/run/fellowship-nas-access.lock"
ACCESS_VERSION = 1
SERVICES = ("smb", "nfs", "sftp")
TITLES = {"smb": "SMB", "nfs": "NFS", "sftp": "SFTP"}
CLIENT_NAME = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
MAX_CLIENTS = 64
MAX_LAN6 = 8
# The widest network one client entry may be
WIDEST = {4: 8, 6: 32}
LINK_LOCAL6 = ipaddress.ip_network("fe80::/10")
# What each way in costs in transit, said when access is given
NOTES = {
    "nfs": "NFS sends files unencrypted and trusts whatever machine has this address. Beyond the home, "
           "connect the two through a VPN or private tunnel (WireGuard or Tailscale), or use SFTP.",
    "smb-desired": "SMB encryption is set to desired, so an older client may connect unencrypted. "
                   "Set it to required in Sharing settings, or connect through a VPN or private tunnel.",
}


def access_settings():
    """The saved access settings, with anything unreadable left out."""
    saved = read_json(ACCESS_FILE, {}) or {}
    lan6 = []
    for prefix in saved.get("lan6") or []:
        try:
            lan6.append(check_lan6(prefix))
        except (FnasError, TypeError):
            continue
    clients = []
    for client in saved.get("clients") or []:
        try:
            clients.append(checked_client(client))
        except (FnasError, TypeError, KeyError, AttributeError):
            continue
    return {"lan6": lan6, "clients": clients}


def save_access(found):
    write_json(ACCESS_FILE, {"version": ACCESS_VERSION, "lan6": found["lan6"], "clients": found["clients"]})


def check_lan6(prefix):
    """An IPv6 prefix the home network really uses: ULA or global unicast, /48 to /64."""
    try:
        network = ipaddress.IPv6Network(prefix, strict=False)
    except (ValueError, TypeError):
        raise FnasError(f"not an IPv6 prefix: {prefix} (expected something like fd12:3456:789a::/64)") from None
    if not 48 <= network.prefixlen <= 64:
        raise FnasError(f"{network}: a local IPv6 prefix is between /48 and /64")
    if network.is_link_local or network.is_multicast or network.is_loopback or network.is_unspecified \
            or network.is_reserved or network.is_site_local:
        raise FnasError(f"{network} isn't a ULA or global prefix (link-local on the LAN port is already local)")
    return str(network)


def check_address(address):
    """One address or a network a client may connect from: IPv4 or IPv6, public
    or private, never everyone and never wider than /8 or /32."""
    try:
        network = ipaddress.ip_network(str(address).strip(), strict=False)
    except ValueError:
        raise FnasError(f"not an address or network: {address} (expected 203.0.113.40 or 10.8.0.0/24)") from None
    if network.prefixlen < WIDEST[network.version]:
        raise FnasError(f"{network} is too wide: a client is at most a /{WIDEST[network.version]} network")
    if network.is_unspecified or network.is_loopback or network.is_multicast or network.is_link_local \
            or (network.version == 6 and network.is_site_local):
        raise FnasError(f"{network} can't be a client: it isn't an address another machine connects from")
    return str(network.network_address) if network.num_addresses == 1 else str(network)


def check_nfs_account(name):
    """The account an NFS client acts as: one of the NAS's people."""
    from . import shares
    try:
        account = pwd.getpwnam(name)
    except KeyError:
        raise FnasError(f"no such user: {name}") from None
    if not (ACCOUNT_NAME.match(name) and 1000 <= account.pw_uid < 60000
            and name not in (shares.SHARE_ACCOUNT, shares.OLD_SHARE_ACCOUNT)):
        raise FnasError(f"{name} isn't a person's account, so NFS can't act as it")
    return name


def checked_client(client):
    name = client["name"]
    if not isinstance(name, str) or not CLIENT_NAME.match(name):
        raise FnasError("a client's name uses lower-case letters, numbers and -, and is at most 32 characters")
    found = {"name": name, "address": check_address(client["address"]),
             "smb": bool(client.get("smb")), "sftp": bool(client.get("sftp")), "nfs": client.get("nfs") or None}
    if found["nfs"] is not None and not (isinstance(found["nfs"], str) and ACCOUNT_NAME.match(found["nfs"])):
        raise FnasError("NFS acts as an account name")
    return found


def services_of(client):
    return [service for service in SERVICES if client[service]]


def find_client(found, name):
    for client in found["clients"]:
        if client["name"] == name:
            return client
    raise FnasError(f"no such client: {name}")


def clients_for(service, found=None):
    """The clients authorized for one service."""
    return [c for c in (found or access_settings())["clients"] if c[service]]


def local_networks():
    """The local network: the saved LAN subnet (or, with none saved, the LAN
    port's own subnet), the IPv6 prefixes an admin added, and the LAN port,
    whose link-local addresses count as local."""
    from . import network, shares
    found = {"ipv4": [], "ipv6": list(access_settings()["lan6"]), "interface": None, "saved": True, "fallback": None}
    try:
        found["interface"] = network.lan_interface()[0]
    except (FnasError, ValueError, OSError):
        # No port to name yet, as at the very start of boot: link-local stays out
        pass
    try:
        found["ipv4"] = [shares.lan_subnet()]
    except FnasError:
        found["saved"] = False
        if found["interface"]:
            try:
                address, prefix = network.current_address(found["interface"])
            except (FnasError, ValueError, OSError):
                address = None
            if address:
                subnet = str(ipaddress.ip_network(f"{address}/{prefix}", strict=False))
                found["ipv4"] = [subnet]
                found["fallback"] = subnet
    return found


def notes_for(client):
    """What this client's ways in cost in transit, in plain words."""
    from . import shares
    said = []
    if client["nfs"]:
        said.append(NOTES["nfs"])
    if client["smb"] and shares.sharing_settings()["smb"]["encryption"] != "required":
        said.append(NOTES["smb-desired"])
    return said


def nfs_shares_of(account, known):
    """The shares an NFS client acting as this account reaches, and how: write or
    read, and the IDs its requests are squashed to. A share the account uses only
    through a group is listed apart, since squashed requests carry no groups."""
    from . import shares
    entry = pwd.getpwnam(account)
    by_name = {share["name"]: share for share in known}
    reached, group_only = [], []
    for used in shares.shares_of(account, known):
        share = by_name[used["name"]]
        if not share["nfs"]:
            continue
        if used["through"].startswith("group "):
            group_only.append(share["name"])
            continue
        uid, gid = ((shares.SHARE_ID, shares.SHARE_ID) if used["through"] == "everyone"
                    else (entry.pw_uid, entry.pw_gid))
        reached.append({"share": share["name"], "level": used["level"], "uid": uid, "gid": gid})
    return reached, group_only


def effective_access(found=None):
    """The effective access, for fnas access show and the desktop."""
    from . import shares
    found = found or access_settings()
    local = local_networks()
    known = shares.list_shares()
    clients = []
    for client in found["clients"]:
        shown = {**client, "services": services_of(client), "notes": notes_for(client)}
        if client["nfs"]:
            try:
                reached, group_only = nfs_shares_of(client["nfs"], known)
            except KeyError:
                reached, group_only = [], []
                shown["notes"] = shown["notes"] + [f"NFS acts as {client['nfs']}, who no longer exists"]
            shown["nfs_shares"] = reached
            shown["nfs_group_only"] = group_only
        clients.append(shown)
    share_networks = sorted({c["host"] for s in known if s["nfs"] for c in s["nfs_options"]["clients"]})
    return {"everyone": ["https", "http-redirect"], "local": local, "lan6": found["lan6"],
            "clients": clients, "nfs_networks": share_networks}


def change_access(update, narrows):
    """Carry out one change to the access settings, then rewrite the sharing
    services and the firewall from them. When access narrows the firewall goes
    first, and when it widens the services do, so a failure part way never
    leaves more open than either the old or the new settings allow."""
    from . import firewall, shares
    with locked(ACCESS_LOCK):
        found = access_settings()
        result = update(found)
        save_access(found)
        if narrows:
            firewall.apply_firewall()
            shares.write_config()
        else:
            shares.write_config()
        return result


def add_client(name, address, smb=False, sftp=False, nfs=None):
    client = checked_client({"name": name, "address": address, "smb": smb, "sftp": sftp,
                             "nfs": check_nfs_account(nfs) if nfs else None})
    if not services_of(client):
        raise FnasError("choose at least one service: --smb, --sftp or --nfs-as ACCOUNT")

    def update(found):
        if any(c["name"] == name for c in found["clients"]):
            raise FnasError(f"a client named {name} already exists")
        if len(found["clients"]) >= MAX_CLIENTS:
            raise FnasError(f"at most {MAX_CLIENTS} clients")
        found["clients"].append(client)
        return client
    return change_access(update, narrows=False)


def set_client(name, address=None, smb=None, sftp=None, nfs=None, no_nfs=False):
    if nfs and no_nfs:
        raise FnasError("choose --nfs-as or --no-nfs, not both")
    nfs = check_nfs_account(nfs) if nfs else None
    found = access_settings()
    old = dict(find_client(found, name))
    new = {**old}
    if address is not None:
        new["address"] = check_address(address)
    if smb is not None:
        new["smb"] = smb
    if sftp is not None:
        new["sftp"] = sftp
    if nfs:
        new["nfs"] = nfs
    if no_nfs:
        new["nfs"] = None
    new = checked_client(new)
    if not services_of(new):
        raise FnasError(f"{name} would reach nothing: remove the client instead")
    # Anything taken away, or a new address, narrows; the firewall goes first then
    narrows = new["address"] != old["address"] or any(old[s] and new[s] != old[s] for s in SERVICES)

    def update(saved):
        client = find_client(saved, name)
        client.update(new)
        return client
    return change_access(update, narrows=narrows)


def remove_client(name):
    def update(found):
        client = find_client(found, name)
        found["clients"].remove(client)
        return client
    return change_access(update, narrows=True)


def add_lan6(prefix):
    prefix = check_lan6(prefix)

    def update(found):
        if prefix in found["lan6"]:
            raise FnasError(f"{prefix} is already part of the local network")
        if len(found["lan6"]) >= MAX_LAN6:
            raise FnasError(f"at most {MAX_LAN6} local IPv6 prefixes")
        found["lan6"].append(prefix)
        return prefix
    return change_access(update, narrows=False)


def remove_lan6(prefix):
    prefix = check_lan6(prefix)

    def update(found):
        if prefix not in found["lan6"]:
            raise FnasError(f"{prefix} isn't one of the local IPv6 prefixes")
        found["lan6"].remove(prefix)
        return prefix
    return change_access(update, narrows=True)


def restore_access(saved):
    """Put back access settings saved on a pool, checking each one."""
    if not isinstance(saved, dict):
        return
    found = {"lan6": [check_lan6(p) for p in saved.get("lan6") or []],
             "clients": [checked_client(c) for c in saved.get("clients") or []]}
    save_access(found)


def check_saved_access(saved):
    if saved is None:
        return
    if not isinstance(saved, dict):
        raise FnasError("the saved access settings aren't readable")
    for prefix in saved.get("lan6") or []:
        check_lan6(prefix)
    for client in saved.get("clients") or []:
        checked_client(client)
