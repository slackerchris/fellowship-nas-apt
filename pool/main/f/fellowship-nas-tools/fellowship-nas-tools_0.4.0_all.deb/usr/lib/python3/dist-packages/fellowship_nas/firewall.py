"""The NAS's firewall: one nftables table, written from the access settings
(docs/fellowship-nas-firewall-plan.md).

HTTPS and the port 80 redirect are open to everyone. SMB, NFS and SSH/SFTP
answer the local network and the clients authorized for each, and are judged
by their source before connection state, so taking a client's access away cuts
its open connections at once. Everything else answers the local network only.

The table is fnas's own, `inet fellowship_nas`, loaded in one step with
`nft -f`, so root's own tables are left alone.
"""
import hashlib
import ipaddress
import os
import re
import tempfile

from . import alerts
from .common import STATE_DIR, FnasError, read_json, run, write_file, write_json

TABLE = "fellowship_nas"
NFT = "/usr/sbin/nft"
SAVED = "/etc/fellowshipos/firewall.nft"
FIREWALL_STATE = os.path.join(STATE_DIR, "firewall.json")
INTERFACE = re.compile(r"^[A-Za-z0-9_.:@-]{1,15}$")
# The ports judged by source before anything else, and who reaches them
SERVICE_PORTS = {"smb": ["tcp dport 445"], "nfs": ["tcp dport 2049", "udp dport 2049"], "sftp": ["tcp dport 22"]}
OPEN_PORTS = (80, 443)
ICMP4 = ("echo-request", "destination-unreachable", "time-exceeded")
ICMP6 = ("nd-neighbor-solicit", "nd-neighbor-advert", "nd-router-solicit", "nd-router-advert",
         "packet-too-big", "time-exceeded", "parameter-problem", "echo-request")


def split_networks(networks):
    """IPv4 and IPv6 networks apart, each in canonical form."""
    four, six = [], []
    for network in networks:
        parsed = ipaddress.ip_network(network, strict=False)
        (four if parsed.version == 4 else six).append(str(parsed))
    return sorted(set(four)), sorted(set(six))


def firewall_model():
    """Everything the table is written from, gathered in one place."""
    from . import access, shares
    found = access.access_settings()
    local = access.local_networks()
    known = shares.list_shares()
    share_networks = [c["host"] for s in known if s["nfs"] for c in s["nfs_options"]["clients"]]
    services = {service: [c["address"] for c in found["clients"] if c[service]] for service in access.SERVICES}
    services["nfs"] += share_networks
    return {"local": local["ipv4"] + local["ipv6"], "interface": local["interface"], "services": services}


def nft_set(name, kind, elements):
    lines = [f"    set {name} {{", f"        type {kind}", "        flags interval", "        auto-merge"]
    if elements:
        lines.append(f"        elements = {{ {', '.join(elements)} }}")
    return lines + ["    }"]


def render_rules(found):
    """The table, as nft -f reads it. The first two lines make sure the table
    exists, so the delete never fails, and the whole file loads atomically."""
    interface = found.get("interface")
    if interface and not INTERFACE.match(interface):
        interface = None
    local4, local6 = split_networks(found["local"])
    lines = ["# Written by fnas from the access settings: changes here are overwritten",
             f"table inet {TABLE}", f"delete table inet {TABLE}", f"table inet {TABLE} {{"]
    lines += nft_set("local4", "ipv4_addr", local4) + nft_set("local6", "ipv6_addr", local6)
    for service in sorted(SERVICE_PORTS):
        four, six = split_networks(found["services"].get(service, []))
        lines += nft_set(f"{service}4", "ipv4_addr", four) + nft_set(f"{service}6", "ipv6_addr", six)
    lines += ["", "    chain local {",
              "        ip saddr @local4 accept",
              "        ip6 saddr @local6 accept"]
    if interface:
        lines.append(f'        iifname "{interface}" ip6 saddr fe80::/10 accept')
    lines.append("    }")
    for service in sorted(SERVICE_PORTS):
        lines += ["", f"    chain {service} {{", "        jump local",
                  f"        ip saddr @{service}4 accept", f"        ip6 saddr @{service}6 accept",
                  "        drop", "    }"]
    lines += ["", "    chain input {", "        type filter hook input priority filter; policy drop;",
              '        iif "lo" accept',
              "        # Judged by source before connection state, so revoking a client cuts it off at once"]
    for service in sorted(SERVICE_PORTS):
        lines += [f"        {match} jump {service}" for match in SERVICE_PORTS[service]]
    lines += ["        ct state established,related accept",
              "        ct state invalid drop",
              f"        icmp type {{ {', '.join(ICMP4)} }} accept",
              f"        icmpv6 type {{ {', '.join(ICMP6)} }} accept",
              "        udp sport 67 udp dport 68 accept",
              "        ip6 saddr fe80::/10 udp sport 547 udp dport 546 accept",
              "        # The desktop, Files and WebDAV, and the redirect to them, for everyone",
              f"        tcp dport {{ {', '.join(str(p) for p in OPEN_PORTS)} }} accept",
              "        jump local",
              "    }", "}"]
    return "\n".join(lines) + "\n"


def minimal_rules():
    """The table before any settings can be read, as at the very start of boot:
    HTTPS and the essentials, nothing local yet."""
    return render_rules({"local": [], "interface": None, "services": {}})


# Present only on a booted system: a package installed into an image's chroot
# must not load rules into the build machine or save its network as the NAS's
BOOTED = "/run/systemd/system"


def nft_available():
    return os.path.exists(NFT)


def booted():
    return os.path.isdir(BOOTED)


def rules_digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def loaded_rules():
    """The table as the kernel has it now, or None if it isn't loaded."""
    result = run(NFT, "list", "table", "inet", TABLE, check=False)
    return result.stdout if result.returncode == 0 else None


def load_rules(text):
    """Check the rules, then load them in one step."""
    with tempfile.NamedTemporaryFile("w", suffix=".nft", delete=False) as file:
        file.write(text)
        path = file.name
    try:
        checked = run(NFT, "-c", "-f", path, check=False)
        if checked.returncode != 0:
            raise FnasError("the firewall rules don't check: " + (checked.stderr.strip() or "nft -c failed"))
        loaded = run(NFT, "-f", path, check=False)
        if loaded.returncode != 0:
            raise FnasError("the firewall rules didn't load: " + (loaded.stderr.strip() or "nft -f failed"))
    finally:
        os.unlink(path)


def apply_firewall():
    """Write the table from the settings and load it. A failure keeps the rules
    already loaded, says so with an alert, and is an error for the caller."""
    if not nft_available() or not booted():
        return None
    text = render_rules(firewall_model())
    try:
        load_rules(text)
    except FnasError as error:
        write_json(FIREWALL_STATE, {**read_json(FIREWALL_STATE, {}), "failed": str(error)})
        alerts.send_alert("high", "The firewall wasn't updated",
                          f"{error}. The rules loaded before stay in force until this is fixed.")
        raise
    write_file(SAVED, text)
    write_json(FIREWALL_STATE, {"rendered": rules_digest(text), "listing": rules_digest(loaded_rules() or "")})
    return text


def boot_firewall():
    """At the start of boot, before the network: the last rules saved, or the
    minimal ones. The share refresh after the network writes the full table."""
    if not nft_available():
        return
    try:
        with open(SAVED) as file:
            text = file.read()
        load_rules(text)
    except (OSError, FnasError):
        load_rules(minimal_rules())


def firewall_status():
    """Whether the table is loaded, and whether it is the one the settings say."""
    if not nft_available():
        return {"available": False, "loaded": False, "matches": False, "failed": None}
    state = read_json(FIREWALL_STATE, {}) or {}
    now = loaded_rules()
    expected = render_rules(firewall_model())
    matches = bool(now) and state.get("listing") == rules_digest(now) and state.get("rendered") == rules_digest(expected)
    return {"available": True, "loaded": now is not None, "matches": matches, "failed": state.get("failed")}
