"""The nightly backup of one pool's shares to another pool.

ZFS to ZFS sends datasets with syncoid, so snapshots and properties come with
them. Any other pair copies files with rsync: each night lands as a complete
tree, hardlinked against the previous night so unchanged files use no extra
space, and the last few nights are kept. That brings back a deleted or changed
file even on a pool with no snapshots and no recycle bin
(docs/fellowship-nas-release.md).
"""
import os
import re
import time

from .common import DAY, FnasError, STATE_DIR, locked, read_json, run, write_json
from . import health, pools, shares, snapshots


BACKUP_FILE = "/etc/fellowshipos/nas-backup.json"
BACKUP_STATE = os.path.join(STATE_DIR, "backup.json")
BACKUP_LOCK = os.path.join(STATE_DIR, "backup.lock")
BACKUP_DATASET = "fellowship-backup"
BACKUP_SHARE = re.compile(rf"^[^/]+/{BACKUP_DATASET}/([^/]+)/shares/([^/]+)$")
BACKUP_MAX_AGE = 2 * DAY
# A nightly copy is a folder named for its date; it counts once its stamp is
# written and the latest symlink points at it
NIGHT = re.compile(r"^nightly-(\d{4}-\d{2}-\d{2})$")
STAMP = ".fellowship-backup.json"
LATEST = "latest"
DEFAULT_KEEP = 7
MAX_KEEP = 90


def backup_root(target):
    return f"{target}/{BACKUP_DATASET}"


def root_path(target):
    """Where a pool that isn't ZFS keeps backups: a root-only folder on it,
    never mounted anywhere else and never shared."""
    return os.path.join(pools.mountpoint(target), BACKUP_DATASET)


def job_mode(source, target):
    """ZFS to ZFS keeps its own send; every other pair copies files."""
    return "zfs" if pools.find_pool(source)["engine"] == pools.find_pool(target)["engine"] == "zfs" else "rsync"


def check_keep(keep):
    if not isinstance(keep, int) or isinstance(keep, bool) or not 1 <= keep <= MAX_KEEP:
        raise FnasError(f"nights kept is a whole number between 1 and {MAX_KEEP}")
    return keep


def set_backup(source, target, keep=DEFAULT_KEEP):
    if source == target:
        raise FnasError("a backup needs a second pool, or losing one loses both")
    writable = pools.writable_pools()
    for pool in (source, target):
        if pool not in writable:
            raise FnasError(f"no writable imported pool: {pool}")
    mode = job_mode(source, target)
    settings = {"source": source, "target": target, "since": int(time.time()), "mode": mode}
    if mode == "zfs":
        root = backup_root(target)
        if run("zfs", "list", "-H", "-o", "name", root, check=False).returncode != 0:
            # Never mounted, so nothing can change a backup or share it by accident
            run("zfs", "create", "-o", "mountpoint=none", root)
    else:
        settings["keep"] = check_keep(keep)
        os.makedirs(root_path(target), mode=0o700, exist_ok=True)
    write_json(BACKUP_FILE, settings)


def nights(root):
    """The completed nightly copies in a source's backup folder, oldest first."""
    if not os.path.isdir(root):
        return []
    return [entry for entry in sorted(os.listdir(root))
            if NIGHT.match(entry) and os.path.isfile(os.path.join(root, entry, STAMP))]


def point_latest(root, night):
    """The latest symlink is the commit point: a night counts once it points here."""
    temporary = os.path.join(root, ".latest-new")
    if os.path.lexists(temporary):
        os.remove(temporary)
    os.symlink(night, temporary)
    os.replace(temporary, os.path.join(root, LATEST))


def copy_settings(source, target):
    """Share settings live in the source pool's config folder, so a copy goes
    with the data for a restore to use."""
    folder = pools.engine_for(target).config_dir(target)
    if folder:
        write_json(os.path.join(folder, f"backup-of-{source}.json"),
                   {"shares": shares.saved_settings(pools.find_pool(source))})


def sync_zfs(settings):
    target = f"{backup_root(settings['target'])}/{settings['source']}"
    run("zfs", "create", "-p", target)
    # Syncoid's own snapshot stays until the next run, so the backup pool can be
    # away for longer than Sanoid keeps anything. Properties go too, so a restored
    # share is still a share.
    result = run("syncoid", "--recursive", "--quiet", "--identifier=fellowship", "--sendoptions=p",
                 f"{settings['source']}/shares", f"{target}/shares", check=False, timeout=None)
    if result.returncode != 0:
        return (result.stderr or result.stdout).strip() or "syncoid failed"
    copy_settings(settings["source"], settings["target"])
    return None


def sync_rsync(settings, now=None):
    source, target = settings["source"], settings["target"]
    keep = settings.get("keep", DEFAULT_KEEP)
    source_shares = os.path.join(pools.mountpoint(source), "shares")
    if not os.path.isdir(source_shares):
        return f"{source} has no shares folder"
    root = os.path.join(root_path(target), source)
    os.makedirs(root, exist_ok=True)
    done = nights(root)
    night = "nightly-" + time.strftime("%Y-%m-%d", time.localtime(now))
    command = ["rsync", "-a", "-A", "-X", "--numeric-ids", "--delete"]
    if done:
        # Unchanged files become hardlinks to the previous night, so only what
        # changed uses new space
        command.append(f"--link-dest={os.path.join(root, done[-1], 'shares')}")
    result = run(*command, source_shares + "/", os.path.join(root, night, "shares") + "/",
                 check=False, timeout=None)
    if result.returncode != 0:
        # No stamp and no symlink: a half-written night is never offered
        return (result.stderr or result.stdout).strip() or "rsync failed"
    write_json(os.path.join(root, night, STAMP), {"completed": int(time.time() if now is None else now)})
    point_latest(root, night)
    # Prune only once the new night is committed. A failed removal leaves an old
    # night behind, which is harmless; it never takes the new one with it.
    everything = sorted(set(done + [night]))
    for old in everything[:-keep]:
        run("rm", "-rf", os.path.join(root, old), check=False, timeout=None)
    for entry in os.listdir(root):
        if NIGHT.match(entry) and entry not in everything:
            run("rm", "-rf", os.path.join(root, entry), check=False, timeout=None)
    copy_settings(source, target)
    return None


def sync_backup(settings, now=None):
    """Copy the shares to the backup pool, returning what went wrong, if anything."""
    imported = [p["name"] for p in pools.list_pools()]
    for pool in (settings["source"], settings["target"]):
        if pool not in imported:
            return f"pool {pool} isn't imported"
    if settings.get("mode", "zfs") == "zfs":
        return sync_zfs(settings)
    return sync_rsync(settings, now)


def run_backup():
    settings = read_json(BACKUP_FILE)
    if not settings:
        raise FnasError("no backup job: run fnas backup set POOL TARGET")
    with locked(BACKUP_LOCK, wait=False):
        error = sync_backup(settings)
    state = read_json(BACKUP_STATE, {})
    state.update(last_attempt=int(time.time()), error=error)
    if not error:
        state["last_success"] = state["last_attempt"]
    write_json(BACKUP_STATE, state)
    health.run_checks()
    if error:
        raise FnasError(error)


def backup_status():
    settings = read_json(BACKUP_FILE)
    return {"job": settings, **read_json(BACKUP_STATE, {})} if settings else {"job": None}


def backup_target(pool):
    if pool:
        return pool
    settings = read_json(BACKUP_FILE)
    if not settings:
        raise FnasError("no backup job, so name the backup pool with --from")
    return settings["target"]


def list_backups(pool):
    target = backup_target(pool)
    if pools.find_pool(target)["engine"] == "zfs":
        root = backup_root(target)
        result = run("zfs", "list", "-H", "-o", "name", "-r", root, check=False)
        if result.returncode != 0:
            raise FnasError(f"no backups in {root}")
        backups = []
        for dataset in result.stdout.split():
            match = BACKUP_SHARE.match(dataset)
            if match:
                backups.append({"name": match.group(2), "pool": match.group(1), "dataset": dataset,
                                "snapshots": len(snapshots.list_snapshots(dataset)), "kind": "zfs"})
        return backups
    root = root_path(target)
    backups = []
    for source in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        # A share deleted from the source is gone from the newest night but kept
        # in older ones, so every kept night is asked what it holds
        by_share = {}
        for night in nights(os.path.join(root, source)):
            folder = os.path.join(root, source, night, "shares")
            for name in sorted(os.listdir(folder)):
                if os.path.isdir(os.path.join(folder, name)):
                    by_share.setdefault(name, []).append(night[len("nightly-"):])
        for name, found in sorted(by_share.items()):
            backups.append({"name": name, "pool": source, "dataset": f"{source}/shares/{name}",
                            "snapshots": 0, "kind": "rsync", "versions": len(found),
                            "nights": list(reversed(found))})
    return backups


def pick_night(backup, version):
    kept = backup.get("nights") or []
    if version is None:
        return kept[0]
    if version not in kept:
        raise FnasError(f"no backup of {backup['name']} from {version}; kept nights: {', '.join(kept)}")
    return version


def restore_backup(name, from_pool, to_pool, version=None, as_name=None):
    backups = [b for b in list_backups(from_pool) if b["name"] == name]
    if not backups:
        raise FnasError(f"no backup of {name}")
    if len(backups) > 1:
        raise FnasError(f"{name} has backups from more than one pool")
    backup = backups[0]
    pool = to_pool or backup["pool"]
    if pool not in pools.writable_pools():
        raise FnasError(f"no writable imported pool: {pool}")
    new_name = as_name or name
    if new_name.lower() in [s["name"].lower() for s in shares.list_shares()]:
        raise FnasError(f"a share named {new_name} already exists, and a restore never replaces one")
    if as_name:
        shares.check_name(as_name)
    if backup["kind"] == "rsync":
        night = pick_night(backup, version)
        source = os.path.join(root_path(backup_target(from_pool)), backup["pool"],
                              f"nightly-{night}", "shares", name)
        path = pools.engine_for(pool).create_volume(pool, new_name)
        result = run("rsync", "-a", "-A", "-X", "--numeric-ids", source + "/", path + "/",
                     check=False, timeout=None)
        if result.returncode != 0:
            run("rm", "-rf", path, check=False, timeout=None)
            raise FnasError((result.stderr or result.stdout).strip() or "rsync failed")
    else:
        dataset = f"{pool}/shares/{new_name}"
        if run("zfs", "list", "-H", "-o", "name", dataset, check=False).returncode == 0:
            raise FnasError(f"{dataset} already exists and isn't a share")
        run("syncoid", "--quiet", "--no-sync-snap", "--sendoptions=p", backup["dataset"], dataset, timeout=None)
    folder = pools.engine_for(backup_target(from_pool)).config_dir(backup_target(from_pool))
    saved = read_json(os.path.join(folder, f"backup-of-{backup['pool']}.json"), {}) if folder else {}
    settings = shares.check_settings(new_name, (saved.get("shares") or {}).get(name, {}))
    if not settings and new_name not in [s["name"] for s in shares.list_shares()]:
        # Nothing says how it was shared, so it comes back private
        settings = shares.new_settings("chosen", {"users": {}, "groups": {}}, False, False)
    if settings:
        shares.save_settings(pool, {"name": new_name, **settings})
    shares.write_config()
